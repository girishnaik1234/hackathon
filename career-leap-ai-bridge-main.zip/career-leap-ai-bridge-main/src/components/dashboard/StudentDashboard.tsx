
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  User, 
  Trophy, 
  BookOpen, 
  Briefcase, 
  Target, 
  Calendar,
  Download,
  Star,
  TrendingUp,
  Award,
  LogOut,
  Bell,
  Settings
} from 'lucide-react';
import SkillGraph from './SkillGraph';
import CourseHub from './CourseHub';
import InternshipHub from './InternshipHub';

interface StudentDashboardProps {
  userRole: 'student' | 'employer' | 'admin';
  onLogout: () => void;
}

const StudentDashboard = ({ userRole, onLogout }: StudentDashboardProps) => {
  const [activeTab, setActiveTab] = useState('overview');

  // Mock student data
  const studentData = {
    name: 'Priya Sharma',
    level: 'Intermediate',
    totalPoints: 2450,
    streak: 15,
    completedCourses: 8,
    certificates: 5,
    skillProgress: {
      'Web Development': 85,
      'Data Science': 60,
      'Digital Marketing': 40,
      'Project Management': 70
    },
    recentAchievements: [
      { title: 'React Certification', date: '2 days ago', type: 'certificate' },
      { title: '30-day Streak', date: '1 week ago', type: 'streak' },
      { title: 'JavaScript Master', date: '2 weeks ago', type: 'skill' }
    ]
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-emerald-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-emerald-600 bg-clip-text text-transparent">
                KaushalyaSetu
              </h1>
              <Badge variant="outline" className="bg-gradient-to-r from-blue-500 to-emerald-500 text-white border-0">
                Student Portal
              </Badge>
            </div>
            
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm">
                <Bell className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <Settings className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="sm" onClick={onLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <div className="bg-gradient-to-r from-blue-600 to-emerald-600 text-white rounded-2xl p-8 relative overflow-hidden">
            <div className="relative z-10">
              <h2 className="text-3xl font-bold mb-2">Welcome back, {studentData.name}! 🎉</h2>
              <p className="text-blue-100 mb-6">Continue your learning journey and unlock new opportunities</p>
              
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4 text-center">
                  <Trophy className="w-8 h-8 mx-auto mb-2 text-yellow-300" />
                  <div className="text-2xl font-bold">{studentData.totalPoints}</div>
                  <div className="text-sm text-blue-100">Total Points</div>
                </div>
                <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4 text-center">
                  <Target className="w-8 h-8 mx-auto mb-2 text-orange-300" />
                  <div className="text-2xl font-bold">{studentData.streak}</div>
                  <div className="text-sm text-blue-100">Day Streak</div>
                </div>
                <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4 text-center">
                  <BookOpen className="w-8 h-8 mx-auto mb-2 text-green-300" />
                  <div className="text-2xl font-bold">{studentData.completedCourses}</div>
                  <div className="text-sm text-blue-100">Courses Done</div>
                </div>
                <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4 text-center">
                  <Award className="w-8 h-8 mx-auto mb-2 text-purple-300" />
                  <div className="text-2xl font-bold">{studentData.certificates}</div>
                  <div className="text-sm text-blue-100">Certificates</div>
                </div>
              </div>
            </div>
            <div className="absolute top-0 right-0 transform translate-x-1/2 -translate-y-1/2">
              <div className="w-96 h-96 bg-white/10 rounded-full"></div>
            </div>
          </div>
        </div>

        {/* Main Dashboard Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-white shadow-sm">
            <TabsTrigger value="overview" className="flex items-center space-x-2">
              <User className="w-4 h-4" />
              <span>Overview</span>
            </TabsTrigger>
            <TabsTrigger value="skills" className="flex items-center space-x-2">
              <TrendingUp className="w-4 h-4" />
              <span>Skills</span>
            </TabsTrigger>
            <TabsTrigger value="courses" className="flex items-center space-x-2">
              <BookOpen className="w-4 h-4" />
              <span>Courses</span>
            </TabsTrigger>
            <TabsTrigger value="internships" className="flex items-center space-x-2">
              <Briefcase className="w-4 h-4" />
              <span>Opportunities</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Skill Progress */}
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <TrendingUp className="w-5 h-5 mr-2 text-blue-500" />
                    Skill Progress
                  </CardTitle>
                  <CardDescription>Your current skill levels and growth</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {Object.entries(studentData.skillProgress).map(([skill, progress]) => (
                    <div key={skill} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">{skill}</span>
                        <span className="text-sm text-gray-500">{progress}%</span>
                      </div>
                      <Progress value={progress} className="h-2" />
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Recent Achievements */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Trophy className="w-5 h-5 mr-2 text-yellow-500" />
                    Recent Achievements
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {studentData.recentAchievements.map((achievement, index) => (
                    <div key={index} className="flex items-center space-x-3 p-3 bg-gradient-to-r from-blue-50 to-emerald-50 rounded-lg">
                      <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-emerald-500 rounded-full flex items-center justify-center">
                        {achievement.type === 'certificate' && <Award className="w-5 h-5 text-white" />}
                        {achievement.type === 'streak' && <Target className="w-5 h-5 text-white" />}
                        {achievement.type === 'skill' && <Star className="w-5 h-5 text-white" />}
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-sm">{achievement.title}</p>
                        <p className="text-xs text-gray-500">{achievement.date}</p>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>Get started with these popular actions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <Button className="h-20 flex-col bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700">
                    <BookOpen className="w-6 h-6 mb-2" />
                    Browse Courses
                  </Button>
                  <Button className="h-20 flex-col bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700">
                    <Briefcase className="w-6 h-6 mb-2" />
                    Find Internships
                  </Button>
                  <Button className="h-20 flex-col bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700">
                    <Download className="w-6 h-6 mb-2" />
                    Download Certificates
                  </Button>
                  <Button className="h-20 flex-col bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600">
                    <Calendar className="w-6 h-6 mb-2" />
                    Schedule Learning
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="skills">
            <SkillGraph />
          </TabsContent>

          <TabsContent value="courses">
            <CourseHub />
          </TabsContent>

          <TabsContent value="internships">
            <InternshipHub />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default StudentDashboard;
