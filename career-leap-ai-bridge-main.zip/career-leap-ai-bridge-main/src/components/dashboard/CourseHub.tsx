
import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  BookOpen, 
  Play, 
  Clock, 
  Star, 
  Users, 
  Award, 
  Search,
  Filter,
  Bookmark,
  Download,
  CheckCircle
} from 'lucide-react';

const CourseHub = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = [
    { id: 'all', name: 'All Courses', count: 50 },
    { id: 'web-dev', name: 'Web Development', count: 15 },
    { id: 'data-science', name: 'Data Science', count: 12 },
    { id: 'mobile', name: 'Mobile Development', count: 8 },
    { id: 'design', name: 'UI/UX Design', count: 10 },
    { id: 'business', name: 'Business Skills', count: 5 }
  ];

  const featuredCourses = [
    {
      id: 1,
      title: 'Full Stack Web Development',
      description: 'Master React, Node.js, and MongoDB to build complete web applications',
      instructor: 'Prof. Rajesh Kumar',
      duration: '12 weeks',
      students: 2450,
      rating: 4.8,
      level: 'Intermediate',
      price: 'Free',
      category: 'web-dev',
      progress: 0,
      image: '/placeholder.svg',
      skills: ['React', 'Node.js', 'MongoDB', 'Express'],
      isEnrolled: false
    },
    {
      id: 2,
      title: 'Data Science Fundamentals',
      description: 'Learn Python, statistics, and machine learning basics',
      instructor: 'Dr. Priya Sharma',
      duration: '10 weeks',
      students: 1890,
      rating: 4.9,
      level: 'Beginner',
      price: 'Free',
      category: 'data-science',
      progress: 65,
      image: '/placeholder.svg',
      skills: ['Python', 'Pandas', 'NumPy', 'Matplotlib'],
      isEnrolled: true
    },
    {
      id: 3,
      title: 'Mobile App Development',
      description: 'Build cross-platform mobile apps with React Native',
      instructor: 'Arjun Patel',
      duration: '8 weeks',
      students: 1200,
      rating: 4.7,
      level: 'Intermediate',
      price: 'Free',
      category: 'mobile',
      progress: 0,
      image: '/placeholder.svg',
      skills: ['React Native', 'JavaScript', 'Firebase'],
      isEnrolled: false
    }
  ];

  const enrolledCourses = featuredCourses.filter(course => course.isEnrolled);
  const availableCourses = featuredCourses.filter(course => !course.isEnrolled);

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-blue-600 to-emerald-600 text-white">
        <CardHeader>
          <CardTitle className="flex items-center text-2xl">
            <BookOpen className="w-6 h-6 mr-3" />
            Course Hub
          </CardTitle>
          <CardDescription className="text-blue-100">
            Explore industry-aligned courses and boost your skills
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4 text-center">
              <BookOpen className="w-8 h-8 mx-auto mb-2 text-green-300" />
              <div className="text-2xl font-bold">50+</div>
              <div className="text-sm text-blue-100">Available Courses</div>
            </div>
            <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4 text-center">
              <Award className="w-8 h-8 mx-auto mb-2 text-yellow-300" />
              <div className="text-2xl font-bold">2</div>
              <div className="text-sm text-blue-100">Enrolled Courses</div>
            </div>
            <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4 text-center">
              <CheckCircle className="w-8 h-8 mx-auto mb-2 text-purple-300" />
              <div className="text-2xl font-bold">5</div>
              <div className="text-sm text-blue-100">Completed</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Search and Filter */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search courses..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button variant="outline" className="flex items-center">
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
          </div>

          {/* Categories */}
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category.id)}
                className="text-xs"
              >
                {category.name} ({category.count})
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Course Tabs */}
      <Tabs defaultValue="enrolled" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="enrolled">My Courses</TabsTrigger>
          <TabsTrigger value="browse">Browse Courses</TabsTrigger>
        </TabsList>

        <TabsContent value="enrolled" className="space-y-6">
          {enrolledCourses.length > 0 ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {enrolledCourses.map((course) => (
                <Card key={course.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-lg">{course.title}</CardTitle>
                        <CardDescription className="mt-2">{course.description}</CardDescription>
                      </div>
                      <Button variant="ghost" size="sm">
                        <Bookmark className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between text-sm text-gray-600">
                      <span className="flex items-center">
                        <Users className="w-4 h-4 mr-1" />
                        {course.students} students
                      </span>
                      <span className="flex items-center">
                        <Clock className="w-4 h-4 mr-1" />
                        {course.duration}
                      </span>
                      <span className="flex items-center">
                        <Star className="w-4 h-4 mr-1 text-yellow-500 fill-current" />
                        {course.rating}
                      </span>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">Progress</span>
                        <span className="text-sm text-gray-500">{course.progress}%</span>
                      </div>
                      <Progress value={course.progress} className="h-2" />
                    </div>

                    <div className="flex flex-wrap gap-1">
                      {course.skills.map((skill, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex gap-2">
                      <Button className="flex-1 bg-gradient-to-r from-blue-500 to-emerald-500 hover:from-blue-600 hover:to-emerald-600">
                        <Play className="w-4 h-4 mr-2" />
                        Continue
                      </Button>
                      <Button variant="outline" size="sm">
                        <Download className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="text-center py-12">
                <BookOpen className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                <h3 className="text-lg font-semibold text-gray-600 mb-2">No enrolled courses yet</h3>
                <p className="text-gray-500 mb-4">Start your learning journey by enrolling in a course</p>
                <Button className="bg-gradient-to-r from-blue-500 to-emerald-500 hover:from-blue-600 hover:to-emerald-600">
                  Browse Courses
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="browse" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {availableCourses.map((course) => (
              <Card key={course.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <Badge variant={course.level === 'Beginner' ? 'default' : course.level === 'Intermediate' ? 'secondary' : 'destructive'} className="mb-2">
                      {course.level}
                    </Badge>
                    <Button variant="ghost" size="sm">
                      <Bookmark className="w-4 h-4" />
                    </Button>
                  </div>
                  <CardTitle className="text-lg">{course.title}</CardTitle>
                  <CardDescription>{course.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between text-sm text-gray-600">
                    <span>{course.instructor}</span>
                    <Badge variant="outline" className="text-emerald-600 border-emerald-600">
                      {course.price}
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between text-sm text-gray-600">
                    <span className="flex items-center">
                      <Users className="w-4 h-4 mr-1" />
                      {course.students}
                    </span>
                    <span className="flex items-center">
                      <Clock className="w-4 h-4 mr-1" />
                      {course.duration}
                    </span>
                    <span className="flex items-center">
                      <Star className="w-4 h-4 mr-1 text-yellow-500 fill-current" />
                      {course.rating}
                    </span>
                  </div>

                  <div className="flex flex-wrap gap-1">
                    {course.skills.slice(0, 3).map((skill, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {skill}
                      </Badge>
                    ))}
                    {course.skills.length > 3 && (
                      <Badge variant="secondary" className="text-xs">
                        +{course.skills.length - 3} more
                      </Badge>
                    )}
                  </div>

                  <Button className="w-full bg-gradient-to-r from-blue-500 to-emerald-500 hover:from-blue-600 hover:to-emerald-600">
                    Enroll Now
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default CourseHub;
