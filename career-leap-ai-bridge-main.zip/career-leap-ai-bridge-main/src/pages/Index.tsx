
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { GraduationCap, Users, Award, TrendingUp, ArrowRight, Play, CheckCircle, Star } from 'lucide-react';
import AuthModal from '@/components/auth/AuthModal';
import StudentDashboard from '@/components/dashboard/StudentDashboard';

const Index = () => {
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'student' | 'employer' | 'admin'>('student');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userRole, setUserRole] = useState<'student' | 'employer' | 'admin'>('student');

  const handleLogin = (role: 'student' | 'employer' | 'admin') => {
    setUserRole(role);
    setIsLoggedIn(true);
    setIsAuthModalOpen(false);
  };

  const openAuthModal = (mode: 'student' | 'employer' | 'admin') => {
    setAuthMode(mode);
    setIsAuthModalOpen(true);
  };

  if (isLoggedIn) {
    return <StudentDashboard userRole={userRole} onLogout={() => setIsLoggedIn(false)} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-emerald-900">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-emerald-600/20 backdrop-blur-3xl"></div>
        <div className="relative container mx-auto px-6 py-20">
          <div className="text-center mb-16">
            <Badge className="mb-6 bg-gradient-to-r from-blue-500 to-emerald-500 text-white border-0 px-4 py-2">
              🚀 The Future of Skill Development
            </Badge>
            <h1 className="text-6xl font-bold mb-6 bg-gradient-to-r from-white via-blue-100 to-emerald-100 bg-clip-text text-transparent">
              KaushalyaSetu
            </h1>
            <p className="text-2xl mb-4 text-blue-100 font-light">
              The Smart Skill Bridge Platform
            </p>
            <p className="text-lg text-blue-200 max-w-3xl mx-auto mb-12 leading-relaxed">
              Connect diploma students with industry-ready skills, AI-powered career matching, 
              and verified internship opportunities with MSME employers.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-16">
              <Button 
                size="lg" 
                className="bg-gradient-to-r from-blue-500 to-emerald-500 hover:from-blue-600 hover:to-emerald-600 text-white border-0 px-8 py-4 text-lg"
                onClick={() => openAuthModal('student')}
              >
                <GraduationCap className="mr-2" />
                Start as Student
                <ArrowRight className="ml-2" />
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-blue-300 text-blue-100 hover:bg-blue-500/20 px-8 py-4 text-lg"
                onClick={() => openAuthModal('employer')}
              >
                <Users className="mr-2" />
                Hire Talent
              </Button>
            </div>

            {/* Demo Video Placeholder */}
            <div className="relative max-w-4xl mx-auto">
              <div className="bg-gradient-to-r from-blue-500/10 to-emerald-500/10 backdrop-blur-sm border border-white/20 rounded-2xl p-8 hover:scale-105 transition-transform duration-300">
                <div className="aspect-video bg-gradient-to-br from-blue-800/50 to-emerald-800/50 rounded-xl flex items-center justify-center">
                  <Button size="lg" className="bg-white/20 hover:bg-white/30 text-white border-0">
                    <Play className="mr-2" />
                    Watch Demo
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="container mx-auto px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-20">
          {[
            { icon: GraduationCap, label: "Active Students", value: "10,000+", color: "from-blue-500 to-blue-600" },
            { icon: Users, label: "MSME Partners", value: "500+", color: "from-emerald-500 to-emerald-600" },
            { icon: Award, label: "Certifications", value: "50,000+", color: "from-purple-500 to-purple-600" },
            { icon: TrendingUp, label: "Job Placements", value: "85%", color: "from-orange-500 to-red-500" }
          ].map((stat, index) => (
            <Card key={index} className="bg-white/10 backdrop-blur-sm border-white/20 text-center hover:scale-105 transition-all duration-300">
              <CardContent className="pt-6">
                <div className={`w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r ${stat.color} flex items-center justify-center`}>
                  <stat.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-3xl font-bold text-white mb-2">{stat.value}</h3>
                <p className="text-blue-200">{stat.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Features Section */}
      <div className="container mx-auto px-6 py-16">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-6">
            Why Choose KaushalyaSetu?
          </h2>
          <p className="text-xl text-blue-200 max-w-3xl mx-auto">
            Our AI-powered platform creates personalized learning paths and connects you with the right opportunities.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            {
              title: "AI-Powered Skill Mapping",
              description: "Dynamic skill graphs that visualize your learning journey and suggest optimal career paths.",
              icon: TrendingUp,
              features: ["Visual Progress Tracking", "Personalized Recommendations", "Skill Gap Analysis"]
            },
            {
              title: "Verified Certifications",
              description: "Industry-recognized micro-courses with blockchain-verified certificates and QR codes.",
              icon: Award,
              features: ["Industry Standards", "Blockchain Verified", "Instant Download"]
            },
            {
              title: "Smart Job Matching",
              description: "AI matches your skills with MSME internships and jobs based on compatibility scores.",
              icon: Users,
              features: ["Smart Algorithms", "Real MSME Partners", "High Success Rate"]
            }
          ].map((feature, index) => (
            <Card key={index} className="bg-white/10 backdrop-blur-sm border-white/20 hover:scale-105 transition-all duration-300">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-gradient-to-r from-blue-500 to-emerald-500 flex items-center justify-center mb-4">
                  <feature.icon className="w-6 h-6 text-white" />
                </div>
                <CardTitle className="text-white text-xl">{feature.title}</CardTitle>
                <CardDescription className="text-blue-200">
                  {feature.description}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {feature.features.map((item, idx) => (
                    <div key={idx} className="flex items-center text-blue-100">
                      <CheckCircle className="w-4 h-4 text-emerald-400 mr-2" />
                      <span className="text-sm">{item}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Testimonials */}
      <div className="container mx-auto px-6 py-16">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-6">Success Stories</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            {
              name: "Priya Sharma",
              role: "Diploma Graduate → Software Developer",
              content: "KaushalyaSetu helped me transition from mechanical to software. The skill mapping was incredible!",
              rating: 5
            },
            {
              name: "Rajesh Kumar",
              role: "MSME Owner",
              content: "Found the perfect interns through their AI matching. The quality of candidates is outstanding.",
              rating: 5
            },
            {
              name: "Anita Patel",
              role: "Polytechnic Student",
              content: "The gamified learning and certificates gave me confidence to apply for my dream internship.",
              rating: 5
            }
          ].map((testimonial, index) => (
            <Card key={index} className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardContent className="pt-6">
                <div className="flex mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-blue-100 mb-4 italic">"{testimonial.content}"</p>
                <div>
                  <p className="text-white font-semibold">{testimonial.name}</p>
                  <p className="text-blue-300 text-sm">{testimonial.role}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* CTA Section */}
      <div className="container mx-auto px-6 py-20">
        <div className="text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Bridge Your Career Gap?
          </h2>
          <p className="text-xl text-blue-200 mb-12 max-w-2xl mx-auto">
            Join thousands of students who have successfully transitioned to their dream careers.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-gradient-to-r from-emerald-500 to-blue-500 hover:from-emerald-600 hover:to-blue-600 text-white border-0 px-8 py-4 text-lg"
              onClick={() => openAuthModal('student')}
            >
              Get Started Today
              <ArrowRight className="ml-2" />
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-blue-300 text-blue-100 hover:bg-blue-500/20 px-8 py-4 text-lg"
              onClick={() => openAuthModal('employer')}
            >
              Partner with Us
            </Button>
          </div>
        </div>
      </div>

      <AuthModal 
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        mode={authMode}
        onLogin={handleLogin}
      />
    </div>
  );
};

export default Index;
