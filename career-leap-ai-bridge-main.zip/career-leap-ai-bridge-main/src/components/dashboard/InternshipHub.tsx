
import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Briefcase, 
  MapPin, 
  Clock, 
  Star, 
  Building, 
  Heart,
  Search,
  Filter,
  Send,
  Eye,
  Calendar,
  DollarSign,
  Users
} from 'lucide-react';

const InternshipHub = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('all');

  const internships = [
    {
      id: 1,
      title: 'Frontend Developer Intern',
      company: 'TechStart Solutions',
      location: 'Mumbai, Maharashtra',
      type: 'Remote',
      duration: '3 months',
      stipend: '₹15,000/month',
      posted: '2 days ago',
      applicants: 45,
      rating: 4.5,
      skills: ['React', 'JavaScript', 'CSS', 'Git'],
      description: 'Work on exciting web applications and gain hands-on experience with modern frontend technologies.',
      requirements: 'Basic knowledge of React and JavaScript',
      isBookmarked: false,
      hasApplied: false,
      matchScore: 92
    },
    {
      id: 2,
      title: 'Data Science Intern',
      company: 'Analytics Pro',
      location: 'Bangalore, Karnataka',
      type: 'Hybrid',
      duration: '6 months',
      stipend: '₹20,000/month',
      posted: '1 week ago',
      applicants: 78,
      rating: 4.8,
      skills: ['Python', 'Pandas', 'Machine Learning', 'SQL'],
      description: 'Analyze large datasets and build predictive models for business insights.',
      requirements: 'Python programming and basic statistics knowledge',
      isBookmarked: true,
      hasApplied: false,
      matchScore: 85
    },
    {
      id: 3,
      title: 'Mobile App Developer',
      company: 'AppCraft Studios',
      location: 'Delhi, NCR',
      type: 'On-site',
      duration: '4 months',
      stipend: '₹18,000/month',
      posted: '3 days ago',
      applicants: 32,
      rating: 4.3,
      skills: ['React Native', 'JavaScript', 'Firebase'],
      description: 'Develop cross-platform mobile applications for various clients.',
      requirements: 'Experience with React Native or Flutter',
      isBookmarked: false,
      hasApplied: true,
      matchScore: 78
    }
  ];

  const applications = [
    {
      id: 1,
      position: 'Frontend Developer Intern',
      company: 'TechStart Solutions',
      appliedDate: '2024-01-15',
      status: 'Under Review',
      statusColor: 'bg-yellow-500'
    },
    {
      id: 2,
      position: 'UI/UX Design Intern',
      company: 'Design Hub',
      appliedDate: '2024-01-10',
      status: 'Interview Scheduled',
      statusColor: 'bg-blue-500'
    },
    {
      id: 3,
      position: 'Backend Developer Intern',
      company: 'CodeBase Inc',
      appliedDate: '2024-01-08',
      status: 'Rejected',
      statusColor: 'bg-red-500'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-blue-600 to-emerald-600 text-white">
        <CardHeader>
          <CardTitle className="flex items-center text-2xl">
            <Briefcase className="w-6 h-6 mr-3" />
            Internship Opportunities
          </CardTitle>
          <CardDescription className="text-blue-100">
            Discover internships matched to your skills and career goals
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4 text-center">
              <Briefcase className="w-8 h-8 mx-auto mb-2 text-green-300" />
              <div className="text-2xl font-bold">150+</div>
              <div className="text-sm text-blue-100">Open Positions</div>
            </div>
            <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4 text-center">
              <Building className="w-8 h-8 mx-auto mb-2 text-purple-300" />
              <div className="text-2xl font-bold">50+</div>
              <div className="text-sm text-blue-100">Partner Companies</div>
            </div>
            <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4 text-center">
              <Send className="w-8 h-8 mx-auto mb-2 text-orange-300" />
              <div className="text-2xl font-bold">3</div>
              <div className="text-sm text-blue-100">Applications Sent</div>
            </div>
            <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4 text-center">
              <Star className="w-8 h-8 mx-auto mb-2 text-yellow-300" />
              <div className="text-2xl font-bold">92%</div>
              <div className="text-sm text-blue-100">Match Score</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Search and Filter */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search internships..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <Button variant="outline" className="flex items-center">
                <MapPin className="w-4 h-4 mr-2" />
                Location
              </Button>
              <Button variant="outline" className="flex items-center">
                <Filter className="w-4 h-4 mr-2" />
                Filter
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Internship Tabs */}
      <Tabs defaultValue="browse" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="browse">Browse</TabsTrigger>
          <TabsTrigger value="bookmarked">Saved</TabsTrigger>
          <TabsTrigger value="applications">My Applications</TabsTrigger>
        </TabsList>

        <TabsContent value="browse" className="space-y-6">
          <div className="grid gap-6">
            {internships.map((internship) => (
              <Card key={internship.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <CardTitle className="text-xl">{internship.title}</CardTitle>
                        <Badge className="bg-gradient-to-r from-blue-500 to-emerald-500 text-white">
                          {internship.matchScore}% match
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-gray-600 mb-2">
                        <span className="flex items-center">
                          <Building className="w-4 h-4 mr-1" />
                          {internship.company}
                        </span>
                        <span className="flex items-center">
                          <MapPin className="w-4 h-4 mr-1" />
                          {internship.location}
                        </span>
                        <Badge variant="outline">{internship.type}</Badge>
                      </div>
                      <CardDescription>{internship.description}</CardDescription>
                    </div>
                    <Button variant="ghost" size="sm">
                      <Heart className={`w-4 h-4 ${internship.isBookmarked ? 'fill-red-500 text-red-500' : ''}`} />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div className="flex items-center">
                      <Clock className="w-4 h-4 mr-2 text-gray-400" />
                      <span>{internship.duration}</span>
                    </div>
                    <div className="flex items-center">
                      <DollarSign className="w-4 h-4 mr-2 text-gray-400" />
                      <span>{internship.stipend}</span>
                    </div>
                    <div className="flex items-center">
                      <Users className="w-4 h-4 mr-2 text-gray-400" />
                      <span>{internship.applicants} applicants</span>
                    </div>
                    <div className="flex items-center">
                      <Star className="w-4 h-4 mr-2 text-yellow-500 fill-current" />
                      <span>{internship.rating}</span>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {internship.skills.map((skill, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {skill}
                      </Badge>
                    ))}
                  </div>

                  <div className="flex gap-2">
                    {internship.hasApplied ? (
                      <Button disabled className="flex-1">
                        Applied
                      </Button>
                    ) : (
                      <>
                        <Button className="flex-1 bg-gradient-to-r from-blue-500 to-emerald-500 hover:from-blue-600 hover:to-emerald-600">
                          <Send className="w-4 h-4 mr-2" />
                          Apply Now
                        </Button>
                        <Button variant="outline">
                          <Eye className="w-4 h-4 mr-2" />
                          View Details
                        </Button>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="bookmarked" className="space-y-6">
          <Card>
            <CardContent className="text-center py-12">
              <Heart className="w-16 h-16 mx-auto mb-4 text-gray-400" />
              <h3 className="text-lg font-semibold text-gray-600 mb-2">No saved internships</h3>
              <p className="text-gray-500 mb-4">Bookmark internships to save them for later</p>
              <Button className="bg-gradient-to-r from-blue-500 to-emerald-500 hover:from-blue-600 hover:to-emerald-600">
                Browse Internships
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="applications" className="space-y-6">
          <div className="grid gap-4">
            {applications.map((application) => (
              <Card key={application.id}>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <h4 className="font-semibold text-lg">{application.position}</h4>
                      <p className="text-gray-600">{application.company}</p>
                      <p className="text-sm text-gray-500 flex items-center mt-2">
                        <Calendar className="w-4 h-4 mr-1" />
                        Applied on {new Date(application.appliedDate).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <Badge className={`${application.statusColor} text-white`}>
                        {application.status}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default InternshipHub;
