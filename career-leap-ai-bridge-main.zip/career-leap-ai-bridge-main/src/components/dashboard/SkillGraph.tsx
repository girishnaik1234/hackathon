
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { TrendingUp, Target, Award, Plus, Zap } from 'lucide-react';

const SkillGraph = () => {
  const skillData = {
    completed: [
      { name: 'HTML/CSS', level: 'Expert', progress: 95, color: 'from-green-500 to-emerald-500' },
      { name: 'JavaScript', level: 'Advanced', progress: 85, color: 'from-blue-500 to-blue-600' },
      { name: 'React', level: 'Intermediate', progress: 70, color: 'from-purple-500 to-purple-600' },
      { name: 'Node.js', level: 'Beginner', progress: 45, color: 'from-orange-500 to-red-500' }
    ],
    recommended: [
      { name: 'TypeScript', reason: 'Complements your JavaScript skills', demand: 'High' },
      { name: 'MongoDB', reason: 'Perfect for full-stack development', demand: 'Medium' },
      { name: 'Docker', reason: 'Essential for modern deployment', demand: 'High' },
      { name: 'AWS', reason: 'Cloud skills are in demand', demand: 'Very High' }
    ],
    achievements: [
      { title: 'JavaScript Ninja', description: 'Completed advanced JavaScript concepts', date: '1 week ago' },
      { title: 'React Components Master', description: 'Built 10+ complex components', date: '2 weeks ago' },
      { title: 'API Integration Pro', description: 'Successfully integrated 5 APIs', date: '1 month ago' }
    ]
  };

  const getDemandColor = (demand: string) => {
    switch (demand) {
      case 'Very High': return 'bg-red-500';
      case 'High': return 'bg-orange-500';
      case 'Medium': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="space-y-6">
      {/* Skill Overview */}
      <Card className="bg-gradient-to-r from-blue-600 to-emerald-600 text-white">
        <CardHeader>
          <CardTitle className="flex items-center text-2xl">
            <TrendingUp className="w-6 h-6 mr-3" />
            Your Skill Journey
          </CardTitle>
          <CardDescription className="text-blue-100">
            Track your progress and discover new opportunities
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4 text-center">
              <Target className="w-8 h-8 mx-auto mb-2 text-yellow-300" />
              <div className="text-2xl font-bold">4</div>
              <div className="text-sm text-blue-100">Active Skills</div>
            </div>
            <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4 text-center">
              <Award className="w-8 h-8 mx-auto mb-2 text-purple-300" />
              <div className="text-2xl font-bold">74%</div>
              <div className="text-sm text-blue-100">Avg. Progress</div>
            </div>
            <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4 text-center">
              <Zap className="w-8 h-8 mx-auto mb-2 text-orange-300" />
              <div className="text-2xl font-bold">Expert</div>
              <div className="text-sm text-blue-100">Next Level</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Current Skills */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="w-5 h-5 mr-2 text-blue-500" />
              Current Skills
            </CardTitle>
            <CardDescription>Your skill levels and progress</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {skillData.completed.map((skill, index) => (
              <div key={index} className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${skill.color} flex items-center justify-center`}>
                      <span className="text-white font-bold text-sm">{skill.name.split(' ')[0].slice(0, 2)}</span>
                    </div>
                    <div>
                      <h4 className="font-semibold">{skill.name}</h4>
                      <Badge variant="outline" className="text-xs">
                        {skill.level}
                      </Badge>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-blue-600">{skill.progress}%</div>
                  </div>
                </div>
                <Progress value={skill.progress} className="h-2" />
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Recommended Skills */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Plus className="w-5 h-5 mr-2 text-emerald-500" />
              Recommended Skills
            </CardTitle>
            <CardDescription>AI-suggested skills based on your profile</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {skillData.recommended.map((skill, index) => (
              <div key={index} className="p-4 bg-gradient-to-r from-blue-50 to-emerald-50 rounded-lg border border-blue-100">
                <div className="flex items-start justify-between mb-2">
                  <h4 className="font-semibold text-gray-800">{skill.name}</h4>
                  <Badge className={`${getDemandColor(skill.demand)} text-white text-xs`}>
                    {skill.demand}
                  </Badge>
                </div>
                <p className="text-sm text-gray-600 mb-3">{skill.reason}</p>
                <Button size="sm" className="bg-gradient-to-r from-blue-500 to-emerald-500 hover:from-blue-600 hover:to-emerald-600 text-white">
                  Start Learning
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Recent Achievements */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Award className="w-5 h-5 mr-2 text-yellow-500" />
            Recent Skill Achievements
          </CardTitle>
          <CardDescription>Your latest milestones and accomplishments</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {skillData.achievements.map((achievement, index) => (
              <div key={index} className="p-4 bg-gradient-to-br from-yellow-50 to-orange-50 rounded-lg border border-yellow-200">
                <div className="flex items-center mb-2">
                  <Award className="w-6 h-6 text-yellow-500 mr-2" />
                  <h4 className="font-semibold text-gray-800">{achievement.title}</h4>
                </div>
                <p className="text-sm text-gray-600 mb-2">{achievement.description}</p>
                <p className="text-xs text-gray-500">{achievement.date}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SkillGraph;
